
package com.ibm.mobileappbuilder.storesreview20160225105920.ds;
import ibmmobileappbuilder.ds.restds.GeoPoint;
import java.util.Date;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class StoresDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("location_1") public String location_1;
    @SerializedName("zone") public Long zone;
    @SerializedName("picture") public String picture;
    @SerializedName("comments") public String comments;
    @SerializedName("location") public GeoPoint location;
    @SerializedName("reviewedon") public Date reviewedon;
    @SerializedName("address") public String address;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(location_1);
        dest.writeValue(zone);
        dest.writeString(picture);
        dest.writeString(comments);
        dest.writeDoubleArray(location != null  && location.coordinates.length != 0 ? location.coordinates : null);
        dest.writeValue(reviewedon != null ? reviewedon.getTime() : null);
        dest.writeString(address);
        dest.writeString(id);
    }

    public static final Creator<StoresDSItem> CREATOR = new Creator<StoresDSItem>() {
        @Override
        public StoresDSItem createFromParcel(Parcel in) {
            StoresDSItem item = new StoresDSItem();

            item.location_1 = in.readString();
            item.zone = (Long) in.readValue(null);
            item.picture = in.readString();
            item.comments = in.readString();
            double[] location_coords = in.createDoubleArray();
            if (location_coords != null)
                item.location = new GeoPoint(location_coords);
            Long reviewedonAux = (Long) in.readValue(null);
            item.reviewedon = reviewedonAux != null ? new Date(reviewedonAux) : null;
            item.address = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public StoresDSItem[] newArray(int size) {
            return new StoresDSItem[size];
        }
    };

}


