package com.ibm.mobileappbuilder.storesreview20160225105920.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;
import ibmmobileappbuilder.behaviors.SearchBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ui.ListGridFragment;
import ibmmobileappbuilder.util.ViewHolder;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.StoresDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.StoresDS;

import static ibmmobileappbuilder.util.NavigationUtils.generateIntentToAddOrUpdateItem;

/**
 * "SeismicZoneWiseListFragment" listing
 */
public class SeismicZoneWiseListFragment extends ListGridFragment<StoresDSItem>  {

    private Datasource<StoresDSItem> datasource;


    public static SeismicZoneWiseListFragment newInstance(Bundle args) {
        SeismicZoneWiseListFragment fr = new SeismicZoneWiseListFragment();

        fr.setArguments(args);
        return fr;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addBehavior(new SearchBehavior(this));
    }

    protected SearchOptions getSearchOptions() {
      SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
      return searchOptionsBuilder.build();
    }


    /**
    * Layout for the list itselft
    */
    @Override
    protected int getLayout() {
        return R.layout.fragment_list;
    }

    /**
    * Layout for each element in the list
    */
    @Override
    protected int getItemLayout() {
        return R.layout.seismiczonewiselist_item;
    }

    @Override
    protected Datasource<StoresDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
      datasource = StoresDS.getInstance(getSearchOptions());
      return datasource;
    }

    @Override
    protected void bindView(StoresDSItem item, View view, int position) {
        
        TextView title = ViewHolder.get(view, R.id.title);
        
        if (item.location_1 != null){
            title.setText(item.location_1);
            
        }
        
        TextView subtitle = ViewHolder.get(view, R.id.subtitle);
        
        if (item.zone != null){
            subtitle.setText("Siesmic Zone: " + item.zone.toString());
            
        }
    }

}

