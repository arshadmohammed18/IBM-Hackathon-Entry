package com.ibm.mobileappbuilder.storesreview20160225105920.ui;

import android.os.Bundle;
import android.widget.TextView;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.restds.GeoPoint;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.StoresDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.StoresDS;

/**
 * "QuakertMapFragment" listing
 */
public class QuakertMapFragment extends ibmmobileappbuilder.maps.ui.MapFragment<StoresDSItem> {
    private Datasource<StoresDSItem> datasource;
    private SearchOptions searchOptions;

    public static QuakertMapFragment newInstance(Bundle args){
        QuakertMapFragment fr = new QuakertMapFragment();
        fr.setArguments(args);

        return fr;
    }

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

	  @Override
    protected Datasource<StoresDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
        searchOptions = SearchOptions.Builder.searchOptions().build();
       datasource = StoresDS.getInstance(searchOptions);
        return datasource;
    }

    @Override
    protected int getMapType() {
        return GoogleMap.MAP_TYPE_TERRAIN;
    }

    @Override
    protected String getLocationField() {
        return "location";
    }

    @Override
    protected Marker createAndBindMarker(GoogleMap map, StoresDSItem item) {
        return map.addMarker(new MarkerOptions()
                        .position(
                                new LatLng(getLocationForItem(item).coordinates[1],
                                        getLocationForItem(item).coordinates[0]))
                        // Binding
                        .title(item.zone.toString() + "★")
        );
    }


    protected GeoPoint getLocationForItem(StoresDSItem item) {
        return item.location;
    }

    @Override
    public void navigateToDetail(StoresDSItem item) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(Constants.CONTENT, item);
        new StartActivityAction(QuakertMapDetailActivity.class, bundle).execute(getActivity());
    }
}

