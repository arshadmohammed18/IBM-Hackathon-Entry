
package com.ibm.mobileappbuilder.storesreview20160225105920.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.StoresDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.StoresDS;

public class QuakertMapDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<StoresDSItem>  {

    private Datasource<StoresDSItem> datasource;
    public static QuakertMapDetailFragment newInstance(Bundle args){
        QuakertMapDetailFragment fr = new QuakertMapDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public QuakertMapDetailFragment(){
        super();
    }

    @Override
    public Datasource<StoresDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = StoresDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.quakertmapdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final StoresDSItem item, View view) {
        if (item.address != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.address);
            
        }
        if (item.zone != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(" " + item.zone.toString());
            
        }
        if (item.reviewedon != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(DateFormat.getMediumDateFormat(getActivity()).format(item.reviewedon));
            
        }
        if (item.location != null){
            
            TextView view3 = (TextView) view.findViewById(R.id.view3);
            view3.setText(item.location.toString());
            
        }
        if (item.comments != null){
            
            TextView view4 = (TextView) view.findViewById(R.id.view4);
            view4.setText(item.comments);
            
        }
    }

    @Override
    protected void onShow(StoresDSItem item) {
        // set the title for this fragment
        getActivity().setTitle(item.location_1);
    }
}

